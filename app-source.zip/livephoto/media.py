"""Local media tools. No shell interpolation, uploads, or implicit downloads."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

FROZEN = bool(getattr(sys, 'frozen', False))
ROOT = Path(sys.executable).resolve().parent if FROZEN else Path(__file__).resolve().parents[1]
if FROZEN and sys.platform == 'darwin' and ROOT.name == 'MacOS' and ROOT.parent.name == 'Contents':
    ROOT = ROOT.parent / 'Resources'
DEFAULT_OUTPUT = Path.home() / 'Movies' / 'LivePhoto' if sys.platform == 'darwin' else ROOT / 'output'


def find_tool(name):
    if FROZEN:
        candidate = ROOT / 'tools' / 'bin' / (name + ('.exe' if sys.platform == 'win32' else ''))
        if not candidate.is_file():
            raise ValueError(f'缺少随附的 {name}，请完整解压便携版 ZIP 后再运行：{candidate}')
        return str(candidate)
    override = os.environ.get(name.upper())
    if override:
        path = Path(override)
        if not path.is_file():
            raise ValueError(f'{name} 指定路径不存在：{path}')
        return str(path)
    executable = name + ('.exe' if os.name == 'nt' else '')
    for folder in (ROOT / 'tools' / 'bin', ROOT / 'tools' / 'ffmpeg'):
        if folder.exists():
            candidate = next(folder.rglob(executable), None)
            if candidate:
                return str(candidate)
    path = shutil.which(name)
    if path:
        return path
    raise ValueError(f'找不到 {name}。将可执行文件放到 tools/bin，或设置 {name.upper()} 环境变量。')


def open_folder(folder):
    if sys.platform == 'win32':
        os.startfile(str(folder))
    else:
        try:
            subprocess.run(['/usr/bin/open' if sys.platform == 'darwin' else 'xdg-open', str(folder)], check=True)
        except subprocess.CalledProcessError as exc:
            raise OSError(f'无法打开目录：{folder}') from exc


def run(name, *args):
    result = subprocess.run(
        [find_tool(name), *map(str, args)], stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding='utf-8',
        errors='replace', creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0,
    )
    if result.returncode:
        raise ValueError(f'{name} 处理失败：\n{result.stderr[-4000:]}')
    return result.stdout


def probe(path):
    return json.loads(run('ffprobe', '-v', 'error', '-show_streams',
                          '-show_format', '-of', 'json', path))


def decode_check(path):
    run('ffmpeg', '-v', 'error', '-xerror', '-nostdin', '-i', path,
        '-map', '0:v:0', '-map', '0:a?', '-f', 'null', '-')
