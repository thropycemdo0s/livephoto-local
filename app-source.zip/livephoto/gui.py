"""Small offline desktop interface; conversion runs outside Tk's UI thread."""
import sys
from pathlib import Path
from queue import Empty, Queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from .core import convert, finite
from .media import DEFAULT_OUTPUT, open_folder


class App:
    def __init__(self, root):
        self.root = root
        self.files = []
        self.events = Queue()
        self.last_output = None
        self.busy = False
        self.output = tk.StringVar(value=str(DEFAULT_OUTPUT))
        self.start = tk.StringVar(value='0')
        self.duration = tk.StringVar(value='')
        self.cover = tk.StringVar(value='')
        self.mute = tk.BooleanVar(value=False)
        self.status = tk.StringVar(value='请选择 CapCut 导出的视频')
        root.title('本地实况转换 · Live Photo')
        root.geometry('740x640')
        root.minsize(640, 580)
        font = 'PingFang SC' if sys.platform == 'darwin' else 'Microsoft YaHei UI'
        root.option_add('*Font', (font, 10))
        style = ttk.Style(root)
        if 'vista' in style.theme_names():
            style.theme_use('vista')
        frame = ttk.Frame(root, padding=22)
        frame.pack(fill='both', expand=True)
        ttk.Label(frame, text='视频 → 实况照片', font=(font, 20, 'bold')).pack(anchor='w')
        ttk.Label(frame, text='免费 · 本地处理 · 支持批量 · 保留声音', foreground='#526579').pack(anchor='w', pady=(5, 18))
        row = ttk.Frame(frame)
        row.pack(fill='x')
        self.add_button = ttk.Button(row, text='选择视频…', command=self.add_files)
        self.add_button.pack(side='left')
        self.clear_button = ttk.Button(row, text='清空列表', command=self.clear_files)
        self.clear_button.pack(side='left', padx=8)
        self.listbox = tk.Listbox(frame, height=5, selectmode='extended', relief='solid', borderwidth=1)
        self.listbox.pack(fill='x', pady=(8, 16))
        settings = ttk.LabelFrame(frame, text='片段设置（秒）', padding=12)
        settings.pack(fill='x')
        for i, (label, variable, hint) in enumerate([
            ('开始', self.start, '从视频何处开始'),
            ('时长', self.duration, '留空保留剩余整段'),
            ('封面', self.cover, '留空取中点；相对片段起点'),
        ]):
            ttk.Label(settings, text=label).grid(row=0, column=i, sticky='w', padx=(0, 12))
            ttk.Entry(settings, textvariable=variable, width=15).grid(row=1, column=i, sticky='ew', padx=(0, 12), pady=4)
            ttk.Label(settings, text=hint, foreground='#526579', font=(font, 8)).grid(row=2, column=i, sticky='w', padx=(0, 12))
            settings.columnconfigure(i, weight=1)
        ttk.Checkbutton(settings, text='静音（默认保留原视频声音）', variable=self.mute).grid(row=3, column=0, columnspan=3, sticky='w', pady=(10, 0))
        dest = ttk.Frame(frame)
        dest.pack(fill='x', pady=16)
        ttk.Label(dest, text='保存到').pack(side='left')
        ttk.Entry(dest, textvariable=self.output).pack(side='left', fill='x', expand=True, padx=10)
        ttk.Button(dest, text='浏览…', command=self.select_output).pack(side='right')
        actions = ttk.Frame(frame)
        actions.pack(fill='x')
        self.convert_button = ttk.Button(actions, text='生成实况照片', command=self.begin)
        self.convert_button.pack(side='left')
        ttk.Button(actions, text='打开成品目录', command=self.open_output).pack(side='left', padx=10)
        self.progress = ttk.Progressbar(frame, mode='indeterminate')
        self.progress.pack(fill='x', pady=(14, 6))
        ttk.Label(frame, textvariable=self.status).pack(anchor='w')
        self.log = tk.Text(frame, height=5, wrap='word', relief='flat', state='disabled', font=('Microsoft YaHei UI', 9))
        self.log.pack(fill='both', expand=True, pady=(8, 0))
        ttk.Label(frame, text='每个片段生成 LIVP 和 JPG/MOV 配对。手机识别及 TikTok 发布效果需实测。',
                  foreground='#526579', font=('Microsoft YaHei UI', 9)).pack(anchor='w', pady=(10, 0))
        root.protocol('WM_DELETE_WINDOW', self.close)
        root.after(100, self.poll)

    def add_files(self):
        selected = filedialog.askopenfilenames(title='选择视频（可多选）', filetypes=[
            ('视频', '*.mp4 *.mov *.m4v *.mkv *.avi *.webm'), ('全部文件', '*.*')])
        for name in selected:
            if name not in self.files:
                self.files.append(name)
                self.listbox.insert('end', name)
        self.status.set(f'已选择 {len(self.files)} 个视频')

    def clear_files(self):
        self.files.clear()
        self.listbox.delete(0, 'end')
        self.status.set('请选择 CapCut 导出的视频')

    def select_output(self):
        selected = filedialog.askdirectory(title='选择成品目录')
        if selected:
            self.output.set(selected)

    def options(self):
        return {'start': finite(self.start.get() or '0', '开始'),
                'duration': finite(self.duration.get(), '时长') if self.duration.get().strip() else None,
                'cover': finite(self.cover.get(), '封面') if self.cover.get().strip() else None,
                'mute': self.mute.get()}

    def begin(self):
        if self.busy:
            return
        if not self.files:
            messagebox.showinfo('选择视频', '请先添加一个或多个视频。')
            return
        try:
            options = self.options()
            if not self.output.get().strip():
                raise ValueError('请选择保存目录')
        except ValueError as exc:
            messagebox.showerror('检查设置', str(exc))
            return
        # Snapshot all Tk values on the UI thread before dispatch.
        sources, output = list(self.files), self.output.get()
        self.busy = True
        for button in (self.convert_button, self.add_button, self.clear_button):
            button.configure(state='disabled')
        self.progress.start(15)
        threading.Thread(target=self.work, args=(sources, output, options), daemon=True).start()

    def work(self, sources, output, options):
        success = failures = 0
        for index, source in enumerate(sources, 1):
            self.events.put(('status', f'正在转换 {index}/{len(sources)}：{Path(source).name}'))
            try:
                path = convert(source, output, **options)
                success += 1
                self.events.put(('success', str(path)))
            except Exception as exc:
                failures += 1
                self.events.put(('error', f'{Path(source).name}：{exc}'))
        self.events.put(('done', (success, failures)))

    def poll(self):
        try:
            while True:
                kind, data = self.events.get_nowait()
                if kind == 'status':
                    self.status.set(data)
                elif kind == 'done':
                    self.busy = False
                    self.progress.stop()
                    for button in (self.convert_button, self.add_button, self.clear_button):
                        button.configure(state='normal')
                    self.status.set(f'完成：成功 {data[0]} 个，失败 {data[1]} 个')
                else:
                    if kind == 'success':
                        self.last_output = Path(data)
                    self.log.configure(state='normal')
                    self.log.insert('end', ('已保存：' if kind == 'success' else '失败：') + data + '\n')
                    self.log.see('end')
                    self.log.configure(state='disabled')
        except Empty:
            pass
        self.root.after(150, self.poll)

    def open_output(self):
        folder = self.last_output or Path(self.output.get())
        if folder.is_dir():
            try:
                open_folder(folder)
            except (OSError, RuntimeError) as exc:
                messagebox.showerror('打开目录失败', str(exc))
        else:
            messagebox.showinfo('尚无成品', '请先完成一次转换。')

    def close(self):
        if self.busy:
            messagebox.showinfo('正在转换', '请等待当前批次完成后关闭窗口。')
        else:
            self.root.destroy()


def launch():
    root = tk.Tk()
    App(root)
    root.mainloop()
