"""Explicit EXIF types for Apple pairing; no camera identity is fabricated.

Pillow's nested dict writer infers BYTE for MakerNote and SHORT for small
dimensions. Write these TIFF entries explicitly so strict ImageIO readers see
UNDEFINED (7) and LONG (4), as required by EXIF.
"""
import struct


def validate_live_exif(data: bytes) -> None:
    """Check serialized TIFF types, which tolerant metadata readers may hide."""
    if not data.startswith(b'Exif\0\0'):
        raise ValueError('JPEG 缺少 EXIF')
    tiff = data[6:]
    if len(tiff) < 8 or tiff[:2] not in (b'MM', b'II'):
        raise ValueError('EXIF TIFF 头无效')
    order = '>' if tiff[:2] == b'MM' else '<'

    def directory(offset):
        if offset < 8 or offset + 2 > len(tiff):
            raise ValueError('EXIF IFD 偏移无效')
        count, = struct.unpack_from(order + 'H', tiff, offset)
        if offset + 2 + count * 12 + 4 > len(tiff):
            raise ValueError('EXIF IFD 长度无效')
        return {tag: (kind, size, value) for tag, kind, size, value in (
            struct.unpack_from(order + 'HHII', tiff, offset + 2 + i * 12)
            for i in range(count))}

    root = directory(struct.unpack_from(order + 'I', tiff, 4)[0])
    pointer = root.get(0x8769)
    if pointer is None or pointer[:2] != (4, 1):
        raise ValueError('JPEG 缺少有效 ExifIFD 指针')
    exif = directory(pointer[2])
    note = exif.get(0x927C)
    if note is None or note[0] != 7:
        raise ValueError('MakerNote 必须使用 UNDEFINED(type 7)，旧版 BYTE 类型不兼容')
    if note[1] < 32 or note[2] + note[1] > len(tiff):
        raise ValueError('MakerNote 数据偏移或长度无效')
    for tag in (0xA002, 0xA003):
        if exif.get(tag, ())[:2] != (4, 1):
            raise ValueError('EXIF 图片尺寸必须使用 LONG(type 4)')


def live_exif(width: int, height: int, maker_note: bytes) -> bytes:
    if not (0 < width <= 0xFFFFFFFF and 0 < height <= 0xFFFFFFFF):
        raise ValueError('Invalid EXIF image dimensions')

    # Allocate IFDs before their variable-length payloads; TIFF offsets are
    # relative to the TIFF header, whereas Apple MakerNote offsets are internal.
    root_count = 7
    exif_count = 7
    root_offset = 8
    exif_offset = root_offset + 2 + root_count * 12 + 4
    data_offset = exif_offset + 2 + exif_count * 12 + 4
    payload = bytearray()

    def entry(tag, kind, count, value):
        if len(value) <= 4:
            field = value.ljust(4, b'\0')
        else:
            field = struct.pack('>I', data_offset + len(payload))
            payload.extend(value)
            if len(payload) % 2:
                payload.append(0)
        return struct.pack('>HHI', tag, kind, count) + field

    software = b'Local Live Photo Converter\0'
    root = [
        entry(0x0112, 3, 1, struct.pack('>H', 1)),  # Orientation, normal
        entry(0x011A, 5, 1, struct.pack('>II', 72, 1)),
        entry(0x011B, 5, 1, struct.pack('>II', 72, 1)),
        entry(0x0128, 3, 1, struct.pack('>H', 2)),
        entry(0x0131, 2, len(software), software),
        entry(0x0213, 3, 1, struct.pack('>H', 1)),  # YCbCr positioning
        entry(0x8769, 4, 1, struct.pack('>I', exif_offset)),
    ]
    exif = [
        entry(0x9000, 7, 4, b'0232'),
        entry(0x9101, 7, 4, b'\x01\x02\x03\x00'),
        entry(0x927C, 7, len(maker_note), maker_note),
        entry(0xA000, 7, 4, b'0100'),
        entry(0xA001, 3, 1, struct.pack('>H', 1)),  # sRGB (SDR output)
        entry(0xA002, 4, 1, struct.pack('>I', width)),
        entry(0xA003, 4, 1, struct.pack('>I', height)),
    ]
    return (b'Exif\0\0MM\0*\0\0\0\x08'
            + struct.pack('>H', root_count) + b''.join(root) + b'\0' * 4
            + struct.pack('>H', exif_count) + b''.join(exif) + b'\0' * 4
            + bytes(payload))
