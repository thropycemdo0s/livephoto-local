import argparse
import json
import sys

from .core import convert, verify
from .media import DEFAULT_OUTPUT


def main():
    parser = argparse.ArgumentParser(description='离线视频转 Apple Live Photo：JPG + MOV + LIVP')
    commands = parser.add_subparsers(dest='command', required=True)
    make = commands.add_parser('convert', help='转换一个或多个视频')
    make.add_argument('inputs', nargs='+')
    make.add_argument('--output', default=str(DEFAULT_OUTPUT))
    make.add_argument('--start', type=float, default=0)
    make.add_argument('--duration', type=float, help='不填则保留剩余整段')
    make.add_argument('--cover', type=float, help='相对于输出片段的封面秒数，默认中点')
    make.add_argument('--mute', action='store_true')
    check = commands.add_parser('verify', help='只读验证一个成品目录')
    check.add_argument('folder')
    commands.add_parser('gui', help='打开中文转换窗口')
    args = parser.parse_args()
    try:
        if args.command == 'gui':
            from .gui import launch
            launch()
            return 0
        if args.command == 'verify':
            result = verify(args.folder)
        else:
            result = {'outputs': [], 'errors': []}
            for source in args.inputs:
                try:
                    result['outputs'].append(str(convert(source, args.output, start=args.start,
                                                         duration=args.duration, cover=args.cover, mute=args.mute)))
                except (ValueError, OSError, KeyError, StopIteration) as exc:
                    result['errors'].append({'source': source, 'error': str(exc)})
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 1 if result['errors'] else 0
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, OSError, KeyError, StopIteration) as exc:
        print(f'错误：{exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
