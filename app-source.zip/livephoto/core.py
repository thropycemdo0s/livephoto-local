"""Transactional video conversion and read-only verification."""
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import tempfile
import uuid
import zipfile

from PIL import Image

from .media import DEFAULT_OUTPUT, decode_check, probe, run
from .vendor.apple import inspect_live_jpeg, inspect_live_mov, write_live_jpeg, write_live_mov

MAX_INPUT_BYTES = 2 * 1024**3
MAX_DURATION = 120


def sha256(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def finite(value, name):
    value = float(value)
    if not math.isfinite(value) or value < 0:
        raise ValueError(f'{name} 必须是大于等于 0 的有限秒数')
    return value


def checked_pair(folder):
    folder = Path(folder)
    jpg, mov = folder / 'LIVE.jpg', folder / 'LIVE.mov'
    asset = inspect_live_jpeg(jpg)
    info = inspect_live_mov(mov)
    if info.asset_id != asset or info.sample_value != -1:
        raise ValueError('实况照片配对标识或封面时间 sample 不匹配')
    data = probe(mov)
    if data['format'].get('tags', {}).get('com.apple.quicktime.content.identifier') != asset:
        raise ValueError('FFprobe 未识别 MOV 配对标识')
    video = next(s for s in data['streams'] if s['codec_type'] == 'video')
    metadata = [s for s in data['streams'] if s['codec_type'] == 'data' and s.get('codec_tag_string') == 'mebx']
    if len(metadata) != 1:
        raise ValueError('MOV 缺少唯一的 mebx 元数据轨道')
    if abs(float(metadata[0]['start_time']) - info.still_time) > 0.002:
        raise ValueError('独立读取的封面时间不一致')
    with Image.open(jpg) as im:
        if im.size != (video['width'], video['height']):
            raise ValueError('封面和视频尺寸不一致')
        im.verify()
    decode_check(mov)
    return {'asset_id': asset, 'duration': float(video['duration']),
            'cover_time': info.still_time, 'width': video['width'],
            'height': video['height'], 'fps': video['avg_frame_rate'],
            'audio': any(s['codec_type'] == 'audio' for s in data['streams'])}


def convert(source, output=None, *, start=0, duration=None, cover=None, mute=False):
    source = Path(source).expanduser().resolve()
    if not source.is_file():
        raise ValueError(f'输入文件不存在：{source}')
    if source.stat().st_size > MAX_INPUT_BYTES:
        raise ValueError('本工具暂限输入 2 GiB；请先裁剪。这不是 TikTok 限制。')
    start = finite(start, '开始时间')
    source_info = probe(source)
    videos = [s for s in source_info['streams'] if s['codec_type'] == 'video'
              and not s.get('disposition', {}).get('attached_pic')]
    if not videos:
        raise ValueError('输入文件没有视频轨道')
    video = videos[0]
    if video.get('color_transfer') in {'smpte2084', 'arib-std-b67'}:
        raise ValueError('当前版本仅支持 SDR。请在 CapCut 导出 SDR 视频后转换，以保持正确颜色。')
    source_duration = float(video.get('duration') or source_info['format']['duration'])
    if not math.isfinite(source_duration) or source_duration <= 0 or start >= source_duration:
        raise ValueError('开始时间超出视频，或视频时长无效')
    duration = source_duration - start if duration is None else finite(duration, '片段时长')
    if duration <= 0 or duration > MAX_DURATION or start + duration > source_duration + 0.02:
        raise ValueError('片段时长必须在视频范围内，且为 0～120 秒（不含 0；本地工具限制）')
    cover = duration / 2 if cover is None else finite(cover, '封面时间')
    if cover >= duration:
        raise ValueError('封面时间必须小于片段时长，按输出片段的起点计算')
    # Normalize to a real output frame so the JPG and metadata mark exactly the same frame.
    cover = math.floor(cover * 30 + 1e-7) / 30
    output = Path(output or DEFAULT_OUTPUT).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    asset = str(uuid.uuid4()).upper()
    name = f"{source.stem[:60]}_{datetime.now():%Y%m%d_%H%M%S}_{asset[:8]}"
    destination = output / name
    with tempfile.TemporaryDirectory(prefix='.live-', dir=output) as temp:
        scratch = Path(temp)
        bundle = scratch / 'bundle'
        bundle.mkdir()
        normalized = scratch / 'normalized.mov'
        args = ['-v', 'error', '-nostdin', '-i', source, '-ss', f'{start:.9f}',
                '-t', f'{duration:.9f}', '-map', f"0:{video['index']}"]
        if not mute:
            args += ['-map', '0:a:0?']
        args += ['-map_metadata', '-1', '-map_chapters', '-1',
                 '-vf', 'fps=30,scale=trunc(iw/2)*2:trunc(ih/2)*2,setsar=1',
                 '-c:v', 'libx264', '-preset', 'medium', '-crf', '18',
                 '-pix_fmt', 'yuv420p', '-video_track_timescale', '30000']
        if mute:
            args += ['-an']
        else:
            args += ['-c:a', 'aac', '-b:a', '192k', '-ar', '48000']
        args += ['-f', 'mov', normalized]
        run('ffmpeg', *args)
        normalized_info = probe(normalized)
        actual = float(next(s for s in normalized_info['streams'] if s['codec_type'] == 'video')['duration'])
        cover = min(cover, max(0, actual - 1 / 30))
        still = scratch / 'still.png'
        run('ffmpeg', '-v', 'error', '-nostdin', '-i', normalized,
            '-ss', f'{cover:.9f}', '-frames:v', '1', '-update', '1', still)
        write_live_jpeg(still, bundle / 'LIVE.jpg', asset)
        write_live_mov(normalized, bundle / 'LIVE.mov', asset, cover, actual)
        checks = checked_pair(bundle)
        with zipfile.ZipFile(bundle / 'LIVE.livp', 'w', compression=zipfile.ZIP_STORED) as archive:
            for filename in ('LIVE.jpg', 'LIVE.mov'):
                archive.write(bundle / filename, filename)
        manifest = {
            'version': 1, 'created_utc': datetime.now(timezone.utc).isoformat(),
            'source_name': source.name, 'asset_id': asset,
            'requested': {'start': start, 'duration': duration, 'cover': cover, 'mute': mute},
            'media': checks,
            'verification': {'structure': 'passed', 'media_decode': 'passed',
                             'iphone_import': 'not_tested', 'tiktok_publish': 'not_tested'},
            'files': {name: {'sha256': sha256(bundle / name), 'bytes': (bundle / name).stat().st_size}
                      for name in ('LIVE.jpg', 'LIVE.mov', 'LIVE.livp')},
        }
        (bundle / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
        (bundle / '使用说明.txt').write_text(
            'LIVE.jpg 和 LIVE.mov 为一组 Apple Live Photo 配对资源。\n'
            'LIVE.livp 是上述两个原文件的 ZIP 打包；供支持 LIVP 的导入工具使用。\n'
            '选择配对文件或 LIVP 其中一种导入方式，不需要重复导入。\n'
            '使用爱思助手时，在“照片 > 导入实况照片”中选择 LIVE.jpg 和 LIVE.mov 配对。\n'
            '已验证元数据结构和媒体解码；iPhone 相册识别及 TikTok 发布效果需手机实测。\n', encoding='utf-8')
        verify(bundle)
        bundle.rename(destination)
    return destination


def verify(folder):
    folder = Path(folder).resolve()
    manifest = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
    required = {'LIVE.jpg', 'LIVE.mov', 'LIVE.livp'}
    if set(manifest['files']) != required:
        raise ValueError('成品清单不完整')
    for name in required:
        path = folder / name
        expected = manifest['files'][name]
        if not path.is_file() or path.stat().st_size != expected['bytes'] or sha256(path) != expected['sha256']:
            raise ValueError(f'文件校验失败，成品已变化或损坏：{name}')
    checks = checked_pair(folder)
    if manifest['asset_id'] != checks['asset_id']:
        raise ValueError('清单与配对 UUID 不一致')
    with zipfile.ZipFile(folder / 'LIVE.livp') as z:
        if len(z.namelist()) != 2 or set(z.namelist()) != {'LIVE.jpg', 'LIVE.mov'}:
            raise ValueError('LIVP 内容不完整')
        for name in z.namelist():
            if z.getinfo(name).file_size != (folder / name).stat().st_size:
                raise ValueError('LIVP 内容大小不一致')
            with z.open(name) as f:
                if hashlib.file_digest(f, 'sha256').hexdigest() != sha256(folder / name):
                    raise ValueError('LIVP 内容与原件不一致')
    return {'ok': True, **checks, 'iphone_import': 'not_tested', 'tiktok_publish': 'not_tested'}
