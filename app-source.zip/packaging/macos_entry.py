"""Finder opens the GUI; terminal invocations can use convert/verify/doctor."""
import json
import sys

from livephoto.__main__ import main
from livephoto.gui import App, launch
from livephoto.media import DEFAULT_OUTPUT, find_tool


if __name__ == '__main__':
    for stream in (sys.stdout, sys.stderr):
        if stream is not None:
            stream.reconfigure(encoding='utf-8')
    if sys.argv[1:] == ['doctor']:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        try:
            app = App(root)
            root.update()
            result = {'gui': 'ok', 'tk': root.tk.call('info', 'patchlevel'),
                      'ffmpeg': find_tool('ffmpeg'), 'ffprobe': find_tool('ffprobe'),
                      'output': str(DEFAULT_OUTPUT)}
        finally:
            root.destroy()
        print(json.dumps(result, ensure_ascii=False))
    elif len(sys.argv) > 1:
        raise SystemExit(main())
    else:
        launch()
