"""Test the actual ZIP, relocated and without developer runtime environment."""
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import zipfile


def main():
    archive = Path(sys.argv[1]).resolve()
    env = {name.upper(): value for name, value in os.environ.items()}
    for name in ('PYTHONHOME', 'PYTHONPATH', 'VIRTUAL_ENV', 'TCL_LIBRARY', 'TK_LIBRARY'):
        env.pop(name, None)
    env['PATH'] = str(Path(env['SYSTEMROOT']) / 'System32')
    env['FFMPEG'] = env['FFPROBE'] = 'Z:/nonexistent/developer.exe'

    def run(*args, cwd):
        result = subprocess.run(list(map(str, args)), cwd=cwd, env=env, capture_output=True,
                                encoding='utf-8', timeout=60, creationflags=subprocess.CREATE_NO_WINDOW)
        if result.returncode:
            raise AssertionError(result.stdout + result.stderr)
        return result.stdout

    with tempfile.TemporaryDirectory(prefix='实况 便携测试 ') as temporary:
        work = Path(temporary)
        with zipfile.ZipFile(archive) as bundle:
            assert bundle.testzip() is None
            names = bundle.namelist()
            assert not any('/output/' in n or 'local-runtime.json' in n or 'IMG_0158' in n for n in names)
            bundle.extractall(work)
        root = work / 'LivePhoto-Portable-Windows-x64'
        cli = root / 'LivePhotoCLI.exe'
        source = work / '中文 输入测试.mp4'
        run(root / 'tools/bin/ffmpeg.exe', '-v', 'error', '-f', 'lavfi', '-i',
            'testsrc2=size=320x480:rate=30:duration=3', '-f', 'lavfi', '-i',
            'sine=frequency=440:duration=3', '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
            '-c:a', 'aac', '-shortest', source, cwd=work)
        result = json.loads(run(cli, 'convert', source, '--duration', '2', cwd=work))
        assert not result['errors'], result
        output = Path(result['outputs'][0])
        assert output.parent == root / 'output'
        verification = json.loads(run(cli, 'verify', output, cwd=work))
        assert (output / 'LIVE.jpg').is_file() and (output / 'LIVE.mov').is_file()

        # Exercise the real windowed EXE, observe only its own window, close gracefully.
        startup = subprocess.STARTUPINFO()
        startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startup.wShowWindow = 0
        process = subprocess.Popen([str(root / '实况转换.exe')], cwd=work, env=env, startupinfo=startup)
        user32 = ctypes.WinDLL('user32', use_last_error=True)
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        user32.EnumWindows.argtypes = [callback_type, wintypes.LPARAM]
        user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        user32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        found = []

        @callback_type
        def observe(handle, unused):
            pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(handle, ctypes.byref(pid))
            if pid.value == process.pid:
                title = ctypes.create_unicode_buffer(256)
                user32.GetWindowTextW(handle, title, 256)
                if title.value == '本地实况转换 · Live Photo':
                    found.append(handle)
            return True

        try:
            deadline = time.monotonic() + 15
            while not found and time.monotonic() < deadline and process.poll() is None:
                user32.EnumWindows(observe, 0)
                time.sleep(0.1)
            assert found, 'Frozen GUI window did not initialize'
            user32.PostMessageW(found[0], 0x0010, 0, 0)
            assert process.wait(timeout=10) == 0
        finally:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=10)

        # A damaged extraction must fail clearly rather than use tools on this PC.
        tool = root / 'tools/bin/ffprobe.exe'
        tool.unlink()  # Only the fresh temporary extraction is affected.
        broken = subprocess.run([str(cli), 'convert', str(source)], cwd=work, env=env,
                                capture_output=True, encoding='utf-8', timeout=30,
                                creationflags=subprocess.CREATE_NO_WINDOW)
        assert broken.returncode != 0 and '完整解压' in broken.stdout + broken.stderr

    report = {'archive': archive.name, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
              'zip_integrity': 'passed', 'private_input_excluded': 'passed',
              'relocated_chinese_space_path': 'passed', 'minimal_environment': 'passed',
              'frozen_conversion_and_verification': 'passed', 'default_output_location': 'passed',
              'windowed_gui_start_close': 'passed', 'missing_tool_error': 'passed',
              'environment': 'Same Windows 11 x64 PC, isolated environment; not a second physical PC.',
              'iphone': 'Earlier EXIF-compatible converter output confirmed by user; portable output not retested on phone.',
              'tiktok': 'not tested'}
    report_path = archive.parent / 'portable-verification.json'
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
