"""Build a release using an explicit allowlist; never include user media/config."""
import argparse
import hashlib
import importlib.metadata
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
NAME = 'LivePhoto-Portable-Windows-x64'


def zip_tree(folder, target, prefix=''):
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(folder.rglob('*')):
            if path.is_file():
                archive.write(path, str(Path(prefix) / path.relative_to(folder)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--ffmpeg-dir', required=True, type=Path,
                        help='Gyan essentials extracted folder containing bin, LICENSE, README.txt')
    args = parser.parse_args()
    subprocess.run([sys.executable, '-m', 'PyInstaller', '--noconfirm',
                    str(ROOT / 'packaging/portable.spec')], cwd=ROOT, check=True)
    target = ROOT / 'dist' / NAME
    binaries = target / 'tools/bin'
    binaries.mkdir(parents=True, exist_ok=True)
    for name in ('ffmpeg.exe', 'ffprobe.exe'):
        shutil.copy2(args.ffmpeg_dir / 'bin' / name, binaries / name)
    shutil.copy2(ROOT / 'packaging/使用说明.txt', target / '使用说明.txt')
    licenses = target / 'licenses'
    licenses.mkdir(exist_ok=True)
    for name in ('LICENSE', 'README.txt'):
        shutil.copy2(args.ffmpeg_dir / name, licenses / ('FFmpeg-' + name + ('.txt' if name == 'LICENSE' else '')))
    shutil.copy2(Path(sys.base_prefix) / 'LICENSE.txt', licenses / 'Python-LICENSE.txt')
    pillow = importlib.metadata.distribution('Pillow')
    for item in pillow.files:
        if '.dist-info/licenses/' in str(item).replace('\\', '/'):
            path = Path(pillow.locate_file(item))
            if path.is_file():
                relative = str(item).replace('\\', '/').split('.dist-info/licenses/', 1)[1]
                destination = licenses / 'Pillow' / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, destination)
    for name in ('LICENSE', 'NOTICE', 'UPSTREAM.txt'):
        shutil.copy2(ROOT / 'livephoto/vendor' / name, licenses / ('LivePhoto-upstream-' + name))
    (licenses / '第三方组件.txt').write_text(
        'Python 3.12: https://www.python.org/downloads/source/\n'
        'Pillow 12.3.0: https://github.com/python-pillow/Pillow\n'
        'Tcl/Tk: licenses are also in _internal/_tcl_data and _internal/_tk_data.\n'
        'PyInstaller 6.22.2: GPL with bootloader exception; https://pyinstaller.org/en/stable/license.html\n'
        'FFmpeg 9.0.1 Gyan essentials: GPLv3; build configuration and upstream source revision in FFmpeg-README.txt.\n'
        'Binary distribution: https://www.gyan.dev/ffmpeg/builds/\n'
        'FFmpeg source: https://github.com/FFmpeg/FFmpeg/tree/bf1b838f2a\n'
        'External library source links: https://www.gyan.dev/ffmpeg/builds/#libraries\n'
        'No third-party binaries have been modified.\n', encoding='utf-8')
    source = target / 'source'
    source.mkdir(exist_ok=True)
    with zipfile.ZipFile(source / 'livephoto-source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for folder in ('livephoto', 'packaging', 'tests'):
            for path in sorted((ROOT / folder).rglob('*')):
                if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
                    archive.write(path, path.relative_to(ROOT))
        archive.write(ROOT / 'requirements.txt', 'requirements.txt')
    (source / '构建说明.txt').write_text(
        'Windows x64 + Python 3.12。解压 livephoto-source.zip，进入该目录。\n'
        'python -m venv .build-venv\n'
        '.build-venv\\Scripts\\python.exe -m pip install -r packaging\\requirements-build.txt\n'
        '下载并解压 Gyan FFmpeg 9.0.1 essentials，保留 LICENSE 与 README.txt。\n'
        '.build-venv\\Scripts\\python.exe packaging\\build_portable.py --ffmpeg-dir "解压后的FFmpeg文件夹"\n'
        '成品位于 release。无需联网运行转换器。\n', encoding='utf-8')
    release = ROOT / 'release'
    release.mkdir(exist_ok=True)
    archive = release / (NAME + '-0.2.0.zip')
    zip_tree(target, archive, NAME)
    with archive.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    archive.with_suffix('.zip.sha256.txt').write_text(digest + '  ' + archive.name + '\n', encoding='ascii')
    print(f'RELEASE: {archive}\nBYTES: {archive.stat().st_size}\nSHA256: {digest}')


if __name__ == '__main__':
    main()
