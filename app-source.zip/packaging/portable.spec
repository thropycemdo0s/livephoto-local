from pathlib import Path

root = Path(SPECPATH).parent
gui = Analysis([str(root / 'packaging/gui_entry.py')], pathex=[str(root)],
               binaries=[], datas=[], hiddenimports=[], hookspath=[], runtime_hooks=[], excludes=[])
cli = Analysis([str(root / 'packaging/cli_entry.py')], pathex=[str(root)],
               binaries=[], datas=[], hiddenimports=['livephoto.gui'], hookspath=[], runtime_hooks=[], excludes=[])
gui_pyz = PYZ(gui.pure)
cli_pyz = PYZ(cli.pure)
gui_exe = EXE(gui_pyz, gui.scripts, [], exclude_binaries=True, name='实况转换',
              debug=False, strip=False, upx=False, console=False)
cli_exe = EXE(cli_pyz, cli.scripts, [], exclude_binaries=True, name='LivePhotoCLI',
              debug=False, strip=False, upx=False, console=True)
collect = COLLECT(gui_exe, cli_exe, gui.binaries, gui.datas, cli.binaries, cli.datas,
                  strip=False, upx=False, name='LivePhoto-Portable-Windows-x64')
