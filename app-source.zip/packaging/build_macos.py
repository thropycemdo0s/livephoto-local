"""Native macOS build. FFmpeg dylibs are collected and relocated by PyInstaller."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def command(*args):
    return subprocess.check_output(list(map(str, args)), text=True).strip()


def main():
    if sys.platform != 'darwin':
        raise SystemExit('Mac .app 必须在 macOS 构建；请运行 GitHub Actions 的 Build macOS 工作流。')
    brew = shutil.which('brew')
    if not brew:
        raise SystemExit('构建机需要 Homebrew；最终应用的使用者不需要。')
    arch = platform.machine()
    if arch not in ('arm64', 'x86_64'):
        raise SystemExit(f'Unsupported architecture: {arch}')
    ffmpeg_prefix = Path(command(brew, '--prefix', 'ffmpeg'))
    env = {**os.environ, 'FFMPEG': str(ffmpeg_prefix / 'bin/ffmpeg'),
           'FFPROBE': str(ffmpeg_prefix / 'bin/ffprobe')}
    (ROOT / 'build').mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='mac-stage-', dir=ROOT / 'build') as temporary:
        stage = Path(temporary)
        licenses = stage / 'licenses'
        licenses.mkdir()
        formulas = {'ffmpeg', 'python@3.12', 'python-tk@3.12'}
        for name in ('ffmpeg', 'python-tk@3.12'):
            formulas.update(command(brew, 'deps', '--installed', name).splitlines())
        formulas = sorted(formulas)
        for formula in formulas:
            prefix = Path(command(brew, '--prefix', formula))
            dest = licenses / formula.replace('/', '_')
            dest.mkdir(exist_ok=True)
            # Include Homebrew's exact source URLs/checksums and installed license files.
            (dest / 'formula.json').write_text(command(brew, 'info', '--json=v2', formula), encoding='utf-8')
            for path in prefix.rglob('*'):
                if path.is_file() and path.name.lower().startswith(('license', 'copying', 'copyright', 'notice')):
                    target = dest / path.relative_to(prefix)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(path, target)
        for package in ('Pillow', 'PyInstaller'):
            distribution = importlib.metadata.distribution(package)
            for item in distribution.files:
                if '.dist-info/licenses/' in str(item):
                    origin = Path(distribution.locate_file(item))
                    if origin.is_file():
                        relative = str(item).split('.dist-info/licenses/', 1)[1]
                        target = licenses / package / relative
                        target.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(origin, target)
        for name in ('LICENSE', 'NOTICE', 'UPSTREAM.txt'):
            shutil.copy2(ROOT / 'livephoto/vendor' / name, licenses / ('LivePhoto-' + name))
        (licenses / 'FFmpeg-build.txt').write_text(command(env['FFMPEG'], '-version'), encoding='utf-8')
        env['LIVEPHOTO_MAC_STAGE'] = str(stage)
        subprocess.run([sys.executable, '-m', 'PyInstaller', '--noconfirm',
                        '--distpath', str(ROOT / 'dist/macos'), '--workpath', str(ROOT / 'build/macos'),
                        str(ROOT / 'packaging/macos.spec')], cwd=ROOT, env=env, check=True)
        app = ROOT / 'dist/macos/实况转换.app'
        subprocess.run(['/usr/bin/codesign', '--verify', '--deep', '--strict', str(app)], check=True)
        name = f'LivePhoto-macOS-{arch}-0.3.0'
        package = stage / name
        package.mkdir()
        shutil.copytree(app, package / app.name, symlinks=True)
        shutil.copy2(ROOT / 'packaging/mac-使用说明.txt', package / '使用说明.txt')
        with zipfile.ZipFile(package / 'source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
            for folder in ('livephoto', 'packaging', 'tests', '.github'):
                for path in sorted((ROOT / folder).rglob('*')):
                    if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
                        archive.write(path, path.relative_to(ROOT))
            archive.write(ROOT / 'requirements.txt', 'requirements.txt')
        release = ROOT / 'release'
        release.mkdir(exist_ok=True)
        archive = release / (name + '.zip')
        subprocess.run(['/usr/bin/ditto', '-c', '-k', '--sequesterRsrc', '--keepParent',
                        str(package), str(archive)], check=True)
    subprocess.run([sys.executable, str(ROOT / 'packaging/smoke_macos.py'), str(archive)], check=True)
    with archive.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    archive.with_suffix('.zip.sha256.txt').write_text(digest + '  ' + archive.name + '\n', encoding='ascii')
    print(f'RELEASE: {archive}\nSHA256: {digest}', flush=True)


if __name__ == '__main__':
    main()
