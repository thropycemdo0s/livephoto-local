"""Allowlist the code for web upload; excludes user media, configuration and docs."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    release = ROOT / 'release'
    release.mkdir(exist_ok=True)
    path = release / 'app-source.zip'
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as archive:
        for folder in ('livephoto', 'packaging', 'tests'):
            for item in sorted((ROOT / folder).rglob('*')):
                if item.is_file() and '__pycache__' not in item.parts and item.suffix != '.pyc':
                    archive.write(item, item.relative_to(ROOT))
        archive.write(ROOT / 'requirements.txt', 'requirements.txt')
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    print(f'{path}\nSHA256: {digest}')
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        assert not any(n.startswith(('output/', 'tools/', 'docs/')) or 'local-runtime' in n for n in archive.namelist())
        print(f'{len(archive.namelist())} source files, {path.stat().st_size} bytes; no private media included.')


if __name__ == '__main__':
    main()
