from livephoto.gui import launch

if __name__ == '__main__':
    launch()
