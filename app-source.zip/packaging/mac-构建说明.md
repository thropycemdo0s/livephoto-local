# Mac 构建

这是构建源代码，不是可双击运行的 Mac 成品。成品由 macOS 构建机生成。

## GitHub Actions

将 `livephoto`、`packaging`、`tests`、`.github` 和 `requirements.txt` 提交到仓库根目录。
不要上传私人视频、output、tools、local-runtime.json、开发虚拟环境或整个电脑工作区。

Actions → Build macOS → Run workflow。工作流分别使用 macos-15（Apple 芯片）
和 macos-15-intel（Intel）的标准运行器。只有测试成功后才上传对应架构的 ZIP、
SHA-256 和验证报告。下载 Artifacts 后，里面的版本 ZIP 才是发给使用者的文件。

工作流不发布公开 Release，不使用付费大规格运行器，不更改账户预算。
私有仓库会消耗账户的 Actions 额度；是否在免费额度内以账户实际剩余额度为准。
公开仓库标准运行器免费，但代码会公开，不能为了免费擅自把私人仓库改为公开。

## 在 Mac 上本地构建

需要 macOS 15+，以及 Homebrew。构建使用本机架构。

```sh
brew install python@3.12 python-tk@3.12 ffmpeg exiftool
"$(brew --prefix python@3.12)/bin/python3.12" -m venv .build-venv
.build-venv/bin/python -m pip install -r packaging/requirements-macos.txt
export FFMPEG="$(brew --prefix ffmpeg)/bin/ffmpeg"
export FFPROBE="$(brew --prefix ffmpeg)/bin/ffprobe"
.build-venv/bin/python -m unittest discover -s tests -v
.build-venv/bin/python packaging/build_macos.py
```

最终使用者不需要 Homebrew、Python 或 FFmpeg。应用自带所需运行库。
本构建使用 ad-hoc 签名，不申请付费 Apple 开发者身份，不进行 Developer ID 公证。

## 验证

构建脚本将实际 ZIP 解压到中文及空格路径，用最小环境变量运行其中的应用，
检查 Tk 初始化、默认输出、实况配对、独立 ExifTool 元数据、无外部 dylib 引用、
架构、签名，以及错误输入处理。通过电脑端测试不等同于 iPhone/TikTok 实测。
