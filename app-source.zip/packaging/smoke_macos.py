"""Verify the delivered macOS ZIP with no Homebrew or Python on runtime PATH."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile


def main():
    if sys.platform != 'darwin':
        raise SystemExit('This test requires macOS.')
    archive = Path(sys.argv[1]).resolve()
    exiftool = shutil.which('exiftool')
    if not exiftool:
        raise SystemExit('Build verification requires ExifTool (not shipped in the app).')
    with tempfile.TemporaryDirectory(prefix='实况 Mac 空格 ') as temporary:
        work = Path(temporary).resolve()
        subprocess.run(['/usr/bin/ditto', '-x', '-k', str(archive), str(work)], check=True)
        app = next(work.glob('*/实况转换.app'))
        executable = app / 'Contents/MacOS/实况转换'
        ffmpeg = app / 'Contents/Resources/tools/bin/ffmpeg'
        subprocess.run(['/usr/bin/codesign', '--verify', '--deep', '--strict', str(app)], check=True)
        home = work / '测试用户'
        home.mkdir()
        env = {'HOME': str(home), 'PATH': '/usr/bin:/bin:/usr/sbin:/sbin',
               'TMPDIR': str(work), 'LANG': 'en_US.UTF-8', 'LC_ALL': 'en_US.UTF-8',
               'FFMPEG': '/missing/developer/ffmpeg', 'FFPROBE': '/missing/developer/ffprobe'}

        def run(*args):
            return subprocess.check_output(list(map(str, args)), cwd=work, env=env,
                                           encoding='utf-8', stderr=subprocess.PIPE, timeout=90)

        doctor = json.loads(run(executable, 'doctor'))
        assert doctor['gui'] == 'ok'
        assert Path(doctor['output']) == home / 'Movies/LivePhoto'
        for name in ('ffmpeg', 'ffprobe'):
            assert Path(doctor[name]).resolve().is_relative_to(app.resolve())

        # Inspect the real load commands, not just whether this build host can run it.
        seen = set()
        for path in app.rglob('*'):
            if not path.is_file() or path.resolve() in seen:
                continue
            seen.add(path.resolve())
            with path.open('rb') as stream:
                magic = stream.read(4)
            if magic not in (b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf', b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca'):
                continue
            deps = subprocess.check_output(['/usr/bin/otool', '-L', str(path)], text=True)
            for line in deps.splitlines()[1:]:
                dependency = line.strip().split(' (', 1)[0]
                if dependency.startswith('/') and not dependency.startswith(('/usr/lib/', '/System/Library/')):
                    raise AssertionError(f'External dependency: {path.name}: {dependency}')
            subprocess.run(['/usr/bin/lipo', '-verify_arch', platform.machine(), str(path)], check=True)

        source = work / '中文 输入.mp4'
        run(ffmpeg, '-v', 'error', '-f', 'lavfi', '-i', 'testsrc2=size=320x480:rate=30:duration=3',
            '-f', 'lavfi', '-i', 'sine=frequency=440:duration=3', '-c:v', 'libx264',
            '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-shortest', source)
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        result = json.loads(run(executable, 'convert', source, '--duration', '2', '--cover', '0.5'))
        assert not result['errors'], result
        output = Path(result['outputs'][0])
        assert output.parent == home / 'Movies/LivePhoto'
        json.loads(run(executable, 'verify', output))
        metadata = json.loads(run(exiftool, '-json', '-G1', '-s', '-ee', '-ContentIdentifier',
                                  '-StillImageTime', output / 'LIVE.jpg', output / 'LIVE.mov'))
        assert metadata[0]['Apple:ContentIdentifier'] == metadata[1]['Keys:ContentIdentifier']
        assert metadata[1]['Track3:StillImageTime'] == -1
        assert hashlib.sha256(source.read_bytes()).hexdigest() == digest
        bad = work / 'not a video.mp4'
        bad.write_text('invalid media', encoding='utf-8')
        failure = subprocess.run([str(executable), 'convert', str(bad)], cwd=work, env=env,
                                 capture_output=True, encoding='utf-8', timeout=30)
        assert failure.returncode != 0
        (app / 'Contents/Resources/tools/bin/ffprobe').unlink()
        failure = subprocess.run([str(executable), 'convert', str(source)], cwd=work, env=env,
                                 capture_output=True, encoding='utf-8', timeout=30)
        assert failure.returncode != 0 and '完整解压' in failure.stdout + failure.stderr
    with archive.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    report = {'archive': archive.name, 'sha256': digest, 'macOS': platform.mac_ver()[0],
              'architecture': platform.machine(), 'native_tk_gui_initialization': 'passed',
              'relocated_chinese_space_path': 'passed', 'no_external_dylibs': 'passed',
              'minimal_environment_conversion': 'passed', 'signature': 'ad-hoc verified; not notarized',
              'pair_decode_and_exiftool': 'passed', 'invalid_input_and_missing_tool': 'passed',
              'iphone_import': 'not tested for this build', 'tiktok_publish': 'not tested'}
    archive.with_suffix('.verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
