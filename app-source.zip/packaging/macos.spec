import os
from pathlib import Path
import platform

root = Path(SPECPATH).parent
stage = Path(os.environ['LIVEPHOTO_MAC_STAGE'])
a = Analysis([str(root / 'packaging/macos_entry.py')], pathex=[str(root)],
             binaries=[(os.environ['FFMPEG'], 'tools/bin'), (os.environ['FFPROBE'], 'tools/bin')],
             datas=[(str(stage / 'licenses.zip'), 'licenses')], hiddenimports=[],
             hookspath=[], runtime_hooks=[], excludes=[])
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='实况转换',
          debug=False, strip=False, upx=False, console=False, target_arch=platform.machine())
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name='LivePhoto-macOS')
app = BUNDLE(coll, name='实况转换.app', bundle_identifier='local.livephoto.converter',
             info_plist={'CFBundleShortVersionString': '0.3.1', 'CFBundleVersion': '4',
                         'NSHighResolutionCapable': True, 'LSMinimumSystemVersion': '15.0',
                         'NSHumanReadableCopyright': 'Includes Apache-2.0 upstream Live Photo code; see licenses.'})
