"""Prevent frozen builds from finding tools/output in the developer checkout."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class PortablePathTests(unittest.TestCase):
    def frozen_probe(self, executable, platform='win32'):
        return subprocess.run([
            sys.executable, '-c',
            'import sys,json,shutil,subprocess,pathlib; sys.frozen=True; sys.executable=sys.argv[1]; sys.platform=sys.argv[2]; '
            'from livephoto.media import ROOT,find_tool,DEFAULT_OUTPUT; '
            'print(json.dumps({"root":str(ROOT),"ffmpeg":find_tool("ffmpeg"),"output":str(DEFAULT_OUTPUT)}))',
            str(executable), platform], cwd=ROOT, capture_output=True, encoding='utf-8',
            env={**os.environ, 'FFMPEG': 'Z:/nonexistent/developer/ffmpeg.exe',
                 'PYTHONIOENCODING': 'utf-8'})

    def test_bundled_tools_follow_exe_and_ignore_stale_environment(self):
        with tempfile.TemporaryDirectory(prefix='便携 路径 ') as temp:
            folder = Path(temp).resolve()
            tools = folder / 'tools/bin'
            tools.mkdir(parents=True)
            (tools / 'ffmpeg.exe').touch()
            result = self.frozen_probe(folder / '实况转换.exe')
            self.assertEqual(result.returncode, 0, result.stderr)
            data = json.loads(result.stdout)
            self.assertEqual(Path(data['root']), folder)
            self.assertEqual(Path(data['ffmpeg']), tools / 'ffmpeg.exe')

    def test_missing_bundled_tool_does_not_fall_back_to_developer_machine(self):
        with tempfile.TemporaryDirectory() as temp:
            result = self.frozen_probe(Path(temp) / '实况转换.exe')
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('完整解压', result.stderr)

    def test_mac_bundle_uses_resources_and_writes_outside_app(self):
        with tempfile.TemporaryDirectory(prefix='Mac 中文 ') as temp:
            contents = Path(temp).resolve() / '实况转换.app/Contents'
            tools = contents / 'Resources/tools/bin'
            tools.mkdir(parents=True)
            (tools / 'ffmpeg').touch()
            result = self.frozen_probe(contents / 'MacOS/实况转换', 'darwin')
            self.assertEqual(result.returncode, 0, result.stderr)
            data = json.loads(result.stdout)
            self.assertEqual(Path(data['ffmpeg']), tools / 'ffmpeg')
            self.assertEqual(Path(data['output']), Path.home() / 'Movies/LivePhoto')


if __name__ == '__main__':
    unittest.main()
