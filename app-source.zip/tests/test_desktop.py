"""OS integration: paths with spaces are passed as one argument, never a shell."""
from pathlib import Path
import unittest
from unittest.mock import patch

from livephoto import media


class DesktopTests(unittest.TestCase):
    def test_mac_opens_folder_with_system_finder(self):
        folder = Path('/Users/example/Movies/中文 成品')
        with patch.object(media.sys, 'platform', 'darwin'), patch.object(media.subprocess, 'run') as run:
            media.open_folder(folder)
            run.assert_called_once_with(['/usr/bin/open', str(folder)], check=True)
