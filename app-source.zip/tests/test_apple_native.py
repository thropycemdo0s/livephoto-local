"""Use Apple's own readers, without accessing or modifying a Photos library."""
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from livephoto.core import convert
from livephoto.media import run


@unittest.skipUnless(sys.platform == 'darwin', 'Requires Apple frameworks')
class AppleNativeTests(unittest.TestCase):
    def test_apple_frameworks_recognize_generated_pair(self):
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary).resolve()
            video = base / 'sample.mov'
            run('ffmpeg', '-v', 'error', '-f', 'lavfi', '-i',
                'testsrc2=size=320x480:rate=30:duration=3',
                '-c:v', 'libx264', '-pix_fmt', 'yuv420p', video)
            pair = convert(video, base / 'output', duration=3, cover=1.5)
            result = subprocess.run(['/usr/bin/swift', str(Path(__file__).with_name('apple_pair_probe.swift')),
                                     str(pair / 'LIVE.jpg'), str(pair / 'LIVE.mov')],
                                    capture_output=True, text=True, timeout=180)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
