import tempfile
import tkinter as tk
import unittest
from pathlib import Path


class GuiTests(unittest.TestCase):
    def test_options_parse_and_background_result_updates(self):
        import importlib.util
        self.assertIsNotNone(importlib.util.find_spec('livephoto.gui'), 'GUI not implemented')
        from livephoto.gui import App
        root = tk.Tk()
        root.withdraw()
        try:
            app = App(root)
            app.start.set('1.5')
            app.duration.set('3')
            app.cover.set('1.2')
            self.assertEqual(app.options(), {'start': 1.5, 'duration': 3., 'cover': 1.2, 'mute': False})
            app.duration.set('')
            app.cover.set('')
            self.assertIsNone(app.options()['duration'])
            self.assertIsNone(app.options()['cover'])
            app.events.put(('success', 'C:/converted/sample'))
            app.events.put(('done', (1, 0)))
            app.poll()
            self.assertEqual(app.last_output, Path('C:/converted/sample'))
            self.assertIn('1', app.status.get())
            self.assertEqual(str(app.convert_button['state']), 'normal')
        finally:
            root.destroy()


if __name__ == '__main__':
    unittest.main()
