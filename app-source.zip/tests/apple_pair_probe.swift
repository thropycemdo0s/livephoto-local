import Foundation
import ImageIO
import AVFoundation
import Photos
import AppKit

let jpg = URL(fileURLWithPath: CommandLine.arguments[1])
let mov = URL(fileURLWithPath: CommandLine.arguments[2])
guard let source = CGImageSourceCreateWithURL(jpg as CFURL, nil),
      let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [String: Any] else {
    fatalError("ImageIO cannot open JPEG")
}
print("IMAGEIO_PROPERTIES: \(properties)")
let maker = properties[kCGImagePropertyMakerAppleDictionary as String] as? [String: Any]
let imageID = maker?["17"] as? String
let asset = AVURLAsset(url: mov)
let metadata = asset.metadata(forFormat: .quickTimeMetadata)
let movieID = metadata.first { ($0.key as? String) == "com.apple.quicktime.content.identifier" }?.stringValue
print("IMAGE_ID: \(imageID ?? "MISSING") MOVIE_ID: \(movieID ?? "MISSING")")
guard let imageID = imageID, imageID == movieID else { exit(2) }
var finished = false
var accepted = false
PHLivePhoto.request(withResourceFileURLs: [jpg, mov], placeholderImage: nil,
                    targetSize: .zero, contentMode: .aspectFit) { photo, info in
    print("PHLIVEPHOTO: \(String(describing: photo)) INFO: \(info)")
    if (info[PHLivePhotoInfoIsDegradedKey] as? Bool) == true { return }
    accepted = photo != nil
    finished = true
}
let deadline = Date().addingTimeInterval(30)
while !finished && Date() < deadline {
    RunLoop.current.run(until: Date().addingTimeInterval(0.05))
}
exit(accepted ? 0 : 3)
