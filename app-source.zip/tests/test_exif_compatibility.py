"""Regression for i4Tools import failure: EXIF types, not just UUID text."""
import json
import os
from pathlib import Path
import struct
import subprocess
import tempfile
import unittest

from PIL import Image

from livephoto.vendor.apple import inspect_live_jpeg, write_live_jpeg

ROOT = Path(__file__).resolve().parents[1]
ASSET = '12345678-1234-5678-9ABC-1234567890AB'


def exif_entries(jpg):
    # Inspect actual serialized TIFF entries independently of the writer/Pillow's decoded dict.
    with Image.open(jpg) as im:
        data = im.info['exif'][6:]
    order = '>' if data[:2] == b'MM' else '<'

    def read_ifd(offset):
        count, = struct.unpack_from(order + 'H', data, offset)
        return {tag: (kind, count, value) for tag, kind, count, value in (
            struct.unpack_from(order + 'HHI4s', data, offset + 2 + 12 * i)
            for i in range(count))}

    root = read_ifd(struct.unpack_from(order + 'I', data, 4)[0])
    sub_offset = struct.unpack(order + 'I', root[0x8769][2])[0]
    return root, read_ifd(sub_offset)


class ExifCompatibilityTests(unittest.TestCase):
    def test_reader_rejects_uuid_with_wrong_makernote_type(self):
        with tempfile.TemporaryDirectory() as temp:
            src, dst = Path(temp) / 'cover.png', Path(temp) / 'bad.jpg'
            Image.new('RGB', (96, 64), 'orange').save(src)
            write_live_jpeg(src, dst, ASSET)
            data = dst.read_bytes()
            # Change only the TIFF type to reproduce the first release's defect.
            signature = b'\x92\x7c\x00\x07'
            self.assertIn(signature, data)
            dst.write_bytes(data.replace(signature, b'\x92\x7c\x00\x01', 1))
            with self.assertRaisesRegex(ValueError, 'MakerNote'):
                inspect_live_jpeg(dst)

    def test_required_exif_types_and_independent_validation(self):
        with tempfile.TemporaryDirectory() as temp:
            src, dst = Path(temp) / 'cover.png', Path(temp) / 'live.jpg'
            Image.new('RGB', (96, 64), 'orange').save(src)
            write_live_jpeg(src, dst, ASSET)
            root, exif = exif_entries(dst)
            self.assertEqual(exif[0x927C][0], 7, 'MakerNote must be UNDEFINED, not BYTE')
            self.assertEqual(exif[0xA002][0], 4, 'PixelXDimension must remain LONG')
            self.assertEqual(exif[0xA003][0], 4, 'PixelYDimension must remain LONG')
            self.assertEqual(exif[0x9000][:2], (7, 4))
            self.assertEqual(exif[0x9101][:2], (7, 4))
            self.assertIn(0x0213, root)
            self.assertEqual(inspect_live_jpeg(dst), ASSET)
            exiftool = ROOT / 'tools/exiftool-oliver/ExifTool.exe'
            if exiftool.exists():
                result = subprocess.check_output([
                    str(exiftool), '-json', '-validate', '-warning', '-error', str(dst)],
                    encoding='utf-8', env={**os.environ, 'LC_ALL': 'C', 'LANG': 'C'})
                report = json.loads(result)[0]
                self.assertEqual(report['Validate'], 'OK', report)


if __name__ == '__main__':
    unittest.main()
