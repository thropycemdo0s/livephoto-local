"""Integration tests: broken pairing, timing, paths, or media must fail."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def tool(name):
    override = os.environ.get(name.upper())
    return override or str(next((ROOT / 'tools').rglob(name + '.exe')))


def probe(path):
    return json.loads(subprocess.check_output([
        tool('ffprobe'), '-v', 'error', '-show_streams', '-show_format',
        '-of', 'json', str(path)], encoding='utf-8'))


class ConversionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(prefix='live-test-')
        cls.base = Path(cls.tmp.name)
        cls.source = cls.base / '中文 视频.mp4'
        subprocess.run([tool('ffmpeg'), '-v', 'error', '-f', 'lavfi', '-i',
                        'testsrc2=size=320x480:rate=30:duration=5', '-f', 'lavfi',
                        '-i', 'sine=frequency=440:duration=5', '-c:v', 'libx264',
                        '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-shortest',
                        str(cls.source)], check=True)
        cls.original_hash = hashlib.sha256(cls.source.read_bytes()).hexdigest()

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def cli(self, *args):
        return subprocess.run([sys.executable, '-m', 'livephoto', *map(str, args)],
                              cwd=ROOT, capture_output=True, encoding='utf-8',
                              env={**os.environ, 'PYTHONIOENCODING': 'utf-8'})

    def convert(self, *extra):
        result = self.cli('convert', self.source, '--output', self.base / '成品', *extra)
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        return Path(json.loads(result.stdout)['outputs'][0])

    def test_pair_timing_audio_and_archive_are_real(self):
        from PIL import Image
        out = self.convert('--start', '1', '--duration', '3', '--cover', '1.2')
        manifest = json.loads((out / 'manifest.json').read_text(encoding='utf-8'))
        mov, jpg = next(out.glob('*.mov')), next(out.glob('*.jpg'))
        data = probe(mov)
        self.assertAlmostEqual(float(data['format']['duration']), 3, delta=0.1)
        kinds = {s['codec_type'] for s in data['streams']}
        self.assertEqual(kinds, {'video', 'audio', 'data'})
        meta = next(s for s in data['streams'] if s['codec_type'] == 'data')
        self.assertEqual(meta['codec_tag_string'], 'mebx')
        self.assertAlmostEqual(float(meta['start_time']), 1.2, delta=0.002)
        asset = data['format']['tags']['com.apple.quicktime.content.identifier']
        with Image.open(jpg) as im:
            # EXIF MakerNote must be in the Exif IFD, not IFD0.
            note = im.getexif().get_ifd(0x8769)[0x927C]
            self.assertIn(asset.encode('ascii'), note)
            self.assertEqual(im.size, (320, 480))
        self.assertEqual(manifest['asset_id'], asset)
        exiftool = ROOT / 'tools' / 'exiftool-oliver' / 'ExifTool.exe'
        if exiftool.is_file():
            external = json.loads(subprocess.check_output([
                str(exiftool), '-json', '-G1', '-s', '-ee', '-ContentIdentifier',
                '-StillImageTime', str(jpg), str(mov)], encoding='utf-8',
                env={**os.environ, 'LC_ALL': 'C', 'LC_CTYPE': 'C', 'LANG': 'C'}))
            self.assertEqual(external[0]['Apple:ContentIdentifier'], asset)
            self.assertEqual(external[1]['Keys:ContentIdentifier'], asset)
            self.assertEqual(external[1]['Track3:StillImageTime'], -1)
        # A separate format-level check catches forgetting mvhd.nextTrackID.
        raw = mov.read_bytes()
        at = raw.rfind(b'mvhd') - 4
        size = int.from_bytes(raw[at:at + 4], 'big')
        next_id = int.from_bytes(raw[at + size - 4:at + size], 'big')
        self.assertGreater(next_id, max(int(s['id'], 0) for s in data['streams']))
        with zipfile.ZipFile(next(out.glob('*.livp'))) as z:
            self.assertEqual(set(z.namelist()), {jpg.name, mov.name})
            self.assertEqual(z.read(jpg.name), jpg.read_bytes())
            self.assertEqual(z.read(mov.name), mov.read_bytes())
        decode = subprocess.run([tool('ffmpeg'), '-v', 'error', '-xerror', '-i',
                                 str(mov), '-map', '0:v', '-map', '0:a?',
                                 '-f', 'null', '-'], capture_output=True)
        self.assertEqual(decode.returncode, 0, decode.stderr)
        self.assertEqual(self.cli('verify', out).returncode, 0)
        self.assertEqual(hashlib.sha256(self.source.read_bytes()).hexdigest(), self.original_hash)

    def test_video_without_audio_and_batch_partial_failure(self):
        silent = self.base / 'silent.mp4'
        subprocess.run([tool('ffmpeg'), '-v', 'error', '-i', str(self.source),
                        '-map', '0:v:0', '-c', 'copy', '-an', str(silent)], check=True)
        result = self.cli('convert', self.base / 'does-not-exist.mp4', silent,
                          '--duration', '1', '--cover', '0', '--output', self.base / 'batch')
        self.assertEqual(result.returncode, 1)
        report = json.loads(result.stdout)
        self.assertEqual(len(report['outputs']), 1)
        self.assertEqual(len(report['errors']), 1)
        out = Path(report['outputs'][0])
        data = probe(next(out.glob('*.mov')))
        self.assertEqual({s['codec_type'] for s in data['streams']}, {'video', 'data'})
        self.assertAlmostEqual(float(next(s for s in data['streams'] if s['codec_type'] == 'data')['start_time']), 0)

    def test_hdr_is_rejected_and_rotation_is_applied(self):
        hdr = self.base / 'hdr.mp4'
        rotated = self.base / 'rotated.mp4'
        subprocess.run([tool('ffmpeg'), '-v', 'error', '-i', str(self.source),
                        '-c', 'copy', '-bsf:v', 'h264_metadata=transfer_characteristics=16',
                        str(hdr)], check=True)
        result = self.cli('convert', hdr, '--output', self.base / 'hdr-out')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('SDR', result.stdout)
        subprocess.run([tool('ffmpeg'), '-v', 'error', '-display_rotation:v:0', '90',
                        '-i', str(self.source), '-c', 'copy', str(rotated)], check=True)
        original = next(s for s in probe(rotated)['streams'] if s['codec_type'] == 'video')
        self.assertEqual(original['side_data_list'][0]['rotation'], 90)
        result = self.cli('convert', rotated, '--duration', '1', '--output', self.base / 'rotated-out')
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        data = probe(Path(json.loads(result.stdout)['outputs'][0]) / 'LIVE.mov')
        video = next(s for s in data['streams'] if s['codec_type'] == 'video')
        self.assertEqual((video['width'], video['height']), (480, 320))

    def test_full_duration_mute_and_repeat_do_not_overwrite(self):
        out = self.convert('--mute')
        out2 = self.convert('--mute')
        self.assertNotEqual(out, out2)
        data = probe(next(out.glob('*.mov')))
        self.assertAlmostEqual(float(data['format']['duration']), 5, delta=0.1)
        self.assertNotIn('audio', {s['codec_type'] for s in data['streams']})

    def test_reject_bad_times_and_missing_input(self):
        for args in [('--duration', '0'), ('--start', '-1'), ('--start', '99'),
                     ('--duration', 'nan'), ('--cover', 'inf'),
                     ('--duration', '2', '--cover', '2'), ('--duration', '99')]:
            with self.subTest(args=args):
                result = self.cli('convert', self.source, '--output', self.base / 'bad', *args)
                self.assertNotEqual(result.returncode, 0)
        self.assertFalse(list((self.base / 'bad').glob('*/manifest.json')))
        self.assertNotEqual(self.cli('convert', self.base / 'missing.mp4').returncode, 0)

    def test_verify_detects_changed_pair(self):
        out = self.convert('--duration', '1')
        jpg = next(out.glob('*.jpg'))
        jpg.write_bytes(jpg.read_bytes()[:-10])
        result = self.cli('verify', out)
        self.assertNotEqual(result.returncode, 0)


if __name__ == '__main__':
    unittest.main()
